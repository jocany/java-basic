package com.huawei.core.util;


/********************************************
 * @author: zhang
 * @Description: com.huawei.core.util
 * @Date: 下午 10:35 2018/8/6 0006
 * @Modified By:
 ********************************************/
public class ResponseFailedTest {

}