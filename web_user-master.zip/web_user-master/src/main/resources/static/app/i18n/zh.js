define([],function () {
    return {
      "hello" : "你好"
    };
});