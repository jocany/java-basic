define([],function () {
    return {
        "hello" : "hello"
    };
});