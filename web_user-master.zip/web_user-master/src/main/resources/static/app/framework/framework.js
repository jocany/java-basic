define(["common/router/routeConfig","i18n","constant","angular", "router"], function(routerConfig) {
    var framework = angular.module("framework", ['ui.router']);
    framework.directive("modal",function(){
    	return {
    		templateUrl: 'app/business/common/view/alert.html',
    		scope:{}
    	}
    });
    /*配置动态加载所有的依赖*/
    framework.config(['$controllerProvider', '$compileProvider', '$filterProvider', '$provide',
        function($controllerProvider, $compileProvider, $filterProvider, $provide) {
            framework.registerController = $controllerProvider.register;
            framework.registerDirective = $compileProvider.directive;
            framework.registerFilter = $filterProvider.register;
            framework.registerFactory = $provide.factory;
            framework.registerService = $provide.service;
        }
    ]);

    framework.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {

        if (angular.isArray(routerConfig.routes)) {
            angular.forEach(routerConfig.routes, function(route) {
                $stateProvider.state({
                    name: route.name,
                    url: route.url,
                    templateUrl: route.templateUrl,
                    controller: route.controller,
                    // 设置每个路由的 resolve ， 使用 requirejs 加载 controller 脚本
                    resolve: loader(route.dependencies)
                });
            })
        }else {
            alert("错误的路由配置");
        }

        function loader(dependencies) {
            // 返回路由的 resolve 定义，
            var definition = {
                // resolver 是一个函数， 返回一个 promise 对象；
                resolver: ['$q', '$rootScope', function($q, $rootScope) {
                    // 创建一个延迟执行的 promise 对象
                    var defered = $q.defer();
                    // 使用 requirejs 的 require 方法加载的脚本
                    require(dependencies, function() {
                        $rootScope.$apply(function() {
                            // 加载完脚本之后， 完成 promise 对象；
                            defered.resolve();
                        });
                    });
                    //返回延迟执行的 promise 对象， route 会等待 promise 对象完成
                    return defered.promise;
                }]
            };
            return definition;
        }

        if (routerConfig.defaultRoute != undefined) {
            //$urlRouterProvider.otherwise(routerConfig.defaultRoute);
        }
    }]);
    return framework;
})