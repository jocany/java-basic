define([], function() {
    var interviewCtrl = ['$scope', "interviewService",function($scope,interviewService) {
    	//每页显示10条记录
    	var pageSize = 10;
    	$scope.currentPage = 1;
        $scope.name = "blog首页";
        $scope.interviews = [];
        function initModel(){
        	$scope.model={
        			id:"",
            		title:"",
            		content:""
            };
        }
        $scope.addInteview = function () {
        	var model=$scope.model;
        	
        	interviewService.addInterview(model).then(function (value) {
                if (value.status === 200){
                	model.id=value.data.data;
                	initModel();
                	model.createTime = formatDate(new Date());
                	$scope.interviews.unshift(model);
                	$scope.getAllInterviews();
                    alert("添加面试题 成功");
                }
            })
        }
        $scope.transferValue = function(row,index) {
			$scope.model = row;
			$scope.index = index;
		}
        function formatDate(now1) {
        	var now = new Date(now1);
            var y = now.getFullYear();
            var m1 = now.getMonth() + 1; // 注意js里的月要加1
            m1 = m1>=10?m1:"0"+m1;
            var d = now.getDate();
            d = d >9?d:"0" + d;
            var h = now.getHours(); 
            h = h >9?h:"0" +h;
            var m = now.getMinutes();
            m = m >9?m:"0" +m;
            var s = now.getSeconds();
            s = s >9?s:"0" +s;
            
            return y + "-" + m1 + "-" + d + " " + h + ":" + m + ":" + s; 
        }
        
        $scope.nextPage = function(){
        	$scope.currentPage+=1;
        	$scope.getAllInterviews();
        }
        
        $scope.previousPage = function() {
        	$scope.currentPage-=1;
        	$scope.getAllInterviews();
		}
        $scope.getAllInterviews = function(){
        	$scope.interviews =[];
        	interviewService.getInterviews(pageSize,$scope.currentPage).then(function(response){
            	for(var i=0;i< response.data.data.length;i++){
            		var o = response.data.data[i];
            		o.createTime = formatDate(o.createTime);
            		$scope.interviews.push(o);
            	}
            });
        }
        
        $scope.deleteInterview = function(){
        	interviewService.deleteInterview($scope.model.id).then(function(response){
        		$scope.interviews.splice($scope.index, 1);
        		initModel();
        		$scope.getAllInterviews();
            });
        }
        $scope.getAllInterviews();
    }];

    //引用框架定义的方法
    angular.module("framework").registerController("interviewCtrl",interviewCtrl);
    //return blogCtrl;
})