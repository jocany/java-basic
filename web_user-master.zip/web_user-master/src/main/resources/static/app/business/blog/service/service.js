define(['constant'], function(constant) {
    var articleService = ['$http', function($http) {
    	this.addArticle = function (model) {
            var req = {
                method: 'post',
                url: constant.SERVER.USER_WEB + "/core/v1/article",
                data: model
            };
            return $http(req);
        }
    	
    	this.getArticles = function (model) {
            var req = {
                method: 'get',
                url: constant.SERVER.USER_WEB + "/core/v1/articles",
            };
            return $http(req);
        }
    }];

    //引用框架定义的方法
    angular.module("framework").registerService("articleService", articleService);
})