define([], function() {
    var javaBlogCtrl = ['$scope',"articleService", function($scope,articleService) {
        $scope.name = "blog首页";
        function initModel(){
        	$scope.model={
            		title:"",
            		detail:"",
                    answer:""
            };
        }
        $scope.articleList = [];
        $scope.addArticle = function () {
        	var model=$scope.model;
        	
        	articleService.addArticle(model).then(function (value) {
                if (value.status === 200){
                	model.id=value.data.data;
                	initModel();
                	model.createTime = formatDate(new Date());
                	$scope.articleList.unshift(model);
                    alert("添加文章成功");
                }
            })
        }
        function formatDate(now1) {
        	var now = new Date(now1);
            var y = now.getFullYear();
            var m1 = now.getMonth() + 1; // 注意js里的月要加1
            m1 = m1>=10?m1:"0"+m1;
            var d = now.getDate();
            d = d >9?d:"0" + d;
            var h = now.getHours(); 
            h = h >9?h:"0" +h;
            var m = now.getMinutes();
            m = m >9?m:"0" +m;
            var s = now.getSeconds();
            s = s >9?s:"0" +s;
            
            return y + "-" + m1 + "-" + d + " " + h + ":" + m + ":" + s; 
        } 
        $scope.getArticles = function () {
        	
        	articleService.getArticles().then(function (value) {
                if (value.status === 200){
                	for(var i=0;i< value.data.data.length;i++){
                		var o = value.data.data[i];
                		o.createTime = formatDate(o.createTime);
                		$scope.articleList.push(o);
                	}
                }
            })
        }
        
        $scope.getArticles();
    }];

    //引用框架定义的方法
    angular.module("framework").registerController("javaBlogCtrl",javaBlogCtrl);
    //return blogCtrl;
})