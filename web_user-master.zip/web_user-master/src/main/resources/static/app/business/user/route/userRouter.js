define([], function() {
    return {
        routes :[{
            name: "portal.user",
            url: "/user",
            templateUrl: 'app/business/user/views/index.html',
            controller: 'userCtrl',
            dependencies: ['app/business/user/controller/userCtrl.js','app/business/user/service/service.js']
        },{
            name: "portal.user.list",
            url: "/list",
            templateUrl: 'app/business/user/views/list.html',
            controller: 'userListCtrl',
            dependencies: ['app/business/user/controller/userListCtrl.js','app/business/user/service/service.js']
        }]
    }
});