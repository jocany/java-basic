define(['constant'], function(constant) {
    var userService = ['$http', function($http) {
        /**
         * 借助有道翻译的功能来翻译一些中文，结果不支持跨域，打算后台写接口
         * @param {*} content  要翻译的内容
         */
        this.translate = function(content) {
            var req = {
                method: 'get',
                url: constant.SERVER.USER_WEB + "/core/translate?word=" + content,
            };
            return $http(req);
        }

        /**
         * 添加用户
         * @param user
         * @returns {*}
         */
        this.addUser = function (user) {
            var req = {
                method: 'post',
                url: constant.SERVER.USER_WEB + "/core/user",
                data: user
            };
            return $http(req);

        }

        /**
         * 查询所有的用户
         */
        this.getUsers = function () {
            var req = {
                method: 'get',
                url: constant.SERVER.USER_WEB + "/core/users"
            };
            return $http(req);
        }
        
        /**
         * 删除的用户
         */
        this.deleteUser = function (id) {
            var req = {
                method: 'delete',
                url: constant.SERVER.USER_WEB + "/core/user/" + id
            };
            return $http(req);
        }
        
        /**
         * 更新用户信息
         */
        this.updateUser = function (user) {
            var req = {
                method: 'put',
                url: constant.SERVER.USER_WEB + "/core/user/" + user.id,
                data: user
            };
            return $http(req);

        }
    }];

    //引用框架定义的方法
    angular.module("framework").registerService("userService", userService);
    return userService;
})