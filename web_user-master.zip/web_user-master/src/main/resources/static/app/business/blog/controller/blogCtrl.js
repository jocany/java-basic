define([], function() {
    var blogCtrl = ['$scope', function($scope) {
        $scope.name = "blog首页";
    }];

    //引用框架定义的方法
    angular.module("framework").registerController("blogCtrl",blogCtrl);
    //return blogCtrl;
})