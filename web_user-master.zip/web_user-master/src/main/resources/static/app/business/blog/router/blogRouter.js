define([], function() {
    return {
        routes :[{
            name: "portal.blog",
            url: "/blog",
            templateUrl: 'app/business/blog/index.html',
            controller: 'blogCtrl',
            dependencies: ['app/business/blog/controller/blogCtrl.js']
        },{
            name: "portal.blog.java",
            url: "/java",
            templateUrl: 'app/business/blog/view/java.html',
            controller: 'javaBlogCtrl',
            dependencies: ['app/business/blog/controller/javaBlogCtrl.js',
            	'app/business/blog/service/service.js']
        },{
            name: "portal.blog.shell",
            url: "/shell",
            templateUrl: 'app/business/blog/view/shell.html',
            controller: 'shellBlogCtrl',
            dependencies: ['app/business/blog/controller/shellBlogCtrl.js']
        }]
    }
});