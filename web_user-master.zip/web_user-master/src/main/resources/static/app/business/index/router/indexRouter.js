define([], function() {
    return {
        routes :[{
            name: "portal.index",
            url: "/index",
            templateUrl: 'app/business/blog/index.html',
            dependencies: []
        }]
    }
});