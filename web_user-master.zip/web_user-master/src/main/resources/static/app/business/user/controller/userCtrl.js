define(["i18n"], function(i18n) {
    var userCtrl = ['$scope', '$state',"userService", function($scope,$state, userService) {
        $scope.word = "我是用户主页";
        $scope.result = "";
        $scope.hello = i18n.hello;
        $scope.translate = function(word) {
            userService.translate(word).then(function(value) {
                $scope.result = value.data.data;
                $scope.result = JSON.parse($scope.result).translation;
            });
        }
        $scope.user = {
            userName: "",
            password: ""
        }

    }];

    //引用框架定义的方法
    angular.module("framework").registerController("userCtrl", userCtrl);
    return userCtrl;
})