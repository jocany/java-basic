define(['constant'], function(constant) {
    var interviewService = ['$http', function($http) {
        /**
         * 添加面试题
         * @param user
         * @returns {*}
         */
        this.addInterview = function (model) {
            var req = {
                method: 'post',
                url: constant.SERVER.USER_WEB + "/core/interview",
                data: model
            };
            return $http(req);

        }

        /**
         * 查询所有面试题
         */
        this.getInterviews = function (pageSize,currentPage) {
            var req = {
                method: 'get',
                url: constant.SERVER.USER_WEB + "/core/interviews",
                params:{
                	pageSize:pageSize,
                	currentPage:currentPage
                }
            };
            return $http(req);
        }
        
        /**
         * 删除面试题
         */
        this.deleteInterview = function (id) {
            var req = {
                method: 'delete',
                url: constant.SERVER.USER_WEB + "/core/interview/" + id
            };
            return $http(req);
        }
        
        /**
         * 更新用户信息
         */
        this.updateUser = function (user) {
            var req = {
                method: 'put',
                url: constant.SERVER.USER_WEB + "/core/user/" + user.id,
                data: user
            };
            return $http(req);

        }
    }];

    //引用框架定义的方法
    angular.module("framework").registerService("interviewService", interviewService);
})