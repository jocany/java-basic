define([], function() {
    return {
        routes :[{
            name: "portal.interview",
            url: "/interview",
            templateUrl: 'app/business/interview/views/index.html',
            controller:"interviewCtrl",
            dependencies: ["app/business/interview/controller/interviewCtrl.js","app/business/interview/service/interviewService.js"]
        }]
    }
});