define([], function() {
    var leftMenuCtrl = ['$scope','$state', function($scope,$state) {
        $scope.$on("$stateChangeSuccess",function (event, toState, toParams, fromState, fromParams) {
            $scope.currentState = $state.current.name;
        })
        $scope.containerState = function (stateName) {
            if ($scope.currentState.indexOf(stateName) >= 0){
                return true;
            }
            return false;
        }
        $scope.go = function (stateName) {
                $state.go(stateName);
        }

    }];

    //引用框架定义的方法
    angular.module("framework").registerController("leftMenuCtrl", leftMenuCtrl);
    return leftMenuCtrl;
})