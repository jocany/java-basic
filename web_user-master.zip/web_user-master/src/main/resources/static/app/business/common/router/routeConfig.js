define([], function() {
    var routerCfg = {
        defaultRoute: '/portal/index',
        routes: [{
            name: "portal",
            url: "/portal",
            templateUrl: 'app/business/common/view/leftMenu.html',
            controller: 'leftMenuCtrl',
            dependencies: ['app/business/common/controller/leftMenu.js']
        }]
    };
    var dependency = ["index/router/indexRouter", "user/route/userRouter", "blog/router/blogRouter","interview/router/interviewRouter"];

    require(dependency, function(index, user, blog, interview) {
        routerCfg.routes = routerCfg.routes.concat(index.routes, user.routes, blog.routes, interview.routes);
    });
    return routerCfg;
});