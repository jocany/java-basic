define(["i18n"], function(i18n) {
    var userListCtrl = ["$scope","userService", function($scope,userService) {
        $scope.word = "我是list";
        $scope.result = "";
        function initUser(){
        	$scope.user={
            		nickName:"",
            		userName:"",
                    password:""
            };
        }
        $scope.userList = [];
        $scope.index="";
        $scope.transferValue = function(user,index) {
			$scope.user = user;
			$scope.index = index;
		}
        $scope.getUsers = function () {
            userService.getUsers().then(function (response) {
                $scope.userList = response.data;
            })
        }
        
        $scope.deleteUser = function(){
        	userService.deleteUser($scope.user.id).then(function(response){
        		$scope.userList.splice($scope.index, 1);
        		alert(response.data.message);
        	})
        }
        
        $scope.updateUser = function(){
        	var user=$scope.user;
        	userService.updateUser(user).then(function(response){
        		initUser();
        		$scope.userList.splice($scope.index, 1,user);//替换
        		alert(response.data.message);
        	})
        }

        $scope.addUser = function () {
        	var user=$scope.user;
            userService.addUser(user).then(function (value) {
                if (value.status === 200){
                	initUser();
                	$scope.userList.push(user);
                    alert("添加用户 成功");
                }
            })
        }
        $scope.getUsers();
    }];

    //引用框架定义的方法
    angular.module("framework").registerController("userListCtrl", userListCtrl);
    //return userCtrl;
})