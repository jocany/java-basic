/***
 * 获取浏览器默认语言
 */
function getDefaultLan() {
    var currentLang = navigator.language;
    console.log(currentLang);
    if ("zh-CN" === currentLang){
        return "zh";
    }
    return "en";
}
require.config({
    baseUrl: "app",
    paths: {
        "angular": "lib/angular",
        "router": "lib/angular-ui-router",
        "common": "business/common",
        "i18n": "i18n/" + getDefaultLan(),
        "constant": "framework/constant",
        "user": "business/user",
        "blog": "business/blog",
        "index": "business/index",
        "interview":"business/interview"
    },
    shim: {
        // 需要导出一个名称为 angular 的全局变量， 否则无法使用
        'angular': {
            exports: 'angular'
        },
        'router': {
            exports: 'router',
            deps: ['angular']
        }

    }
})
require(["framework/framework"], function(framework) {
    angular.bootstrap(document, [framework.name]);
})