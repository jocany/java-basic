package com.huawei.core;


import java.util.concurrent.ScheduledThreadPoolExecutor;

import org.apache.activemq.command.ActiveMQQueue;
import org.apache.activemq.command.ActiveMQTopic;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;

import javax.jms.Queue;
import javax.jms.Topic;

@EnableTransactionManagement
@MapperScan(basePackages="com.huawei.core.mapper")
@ComponentScan(basePackages ="com.huawei.core")
@SpringBootApplication
public class WebApplication implements EmbeddedServletContainerCustomizer{

	public static void main(String[] args) {
		SpringApplication.run(WebApplication.class, args);
	}

	@Bean
	public RestTemplate setRestTemplate(){
		return new RestTemplate();
	}

	@Override
	public void customize(ConfigurableEmbeddedServletContainer configurableEmbeddedServletContainer) {
		configurableEmbeddedServletContainer.setPort(80);
	}

	@Bean(destroyMethod = "shutdown")
	public ScheduledThreadPoolExecutor set() {
		ScheduledThreadPoolExecutor pool = new ScheduledThreadPoolExecutor(5);
		pool.setMaximumPoolSize(20);
		pool.setCorePoolSize(30);
	    return pool;
	}


	@Bean
	public Topic topic() {

		return new ActiveMQTopic("sample.topic");

	}

	@Bean
	public Queue queue(){
		return  new ActiveMQQueue("sample.queue");
	}

}
