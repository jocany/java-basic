package com.huawei.core.controller;

import java.util.concurrent.Callable;

import com.huawei.core.mq.Producer;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.jms.Destination;

@RestController
@RequestMapping(value = "core")
public class TestController
{
    private static final Logger LOGGER = Logger.getLogger(TestController.class);


    @Autowired
    private Producer producer;


    /**
     * 异步调用restful
     * 当controller返回值是Callable的时候，springmvc就会启动一个线程将Callable交给TaskExecutor去处理
     * 然后DispatcherServlet还有所有的spring拦截器都退出主线程，然后把response保持打开的状态
     * 当Callable执行结束之后，springmvc就会重新启动分配一个request请求，然后DispatcherServlet就重新
     * 调用和处理Callable异步执行的返回结果， 然后返回视图
     * 
     * @return
     */
    @GetMapping("/hello")
    public Callable<String> helloController() {
        LOGGER.info(Thread.currentThread().getName() + " 进入helloController方法");
        Callable<String> callable = new Callable<String>() {
 
            @Override
            public String call() throws Exception {
                Thread.sleep(20000);
                LOGGER.info(Thread.currentThread().getName() + " 进入call方法");
                String say = "zhangyi异步返回";
                LOGGER.info(Thread.currentThread().getName() + " 从helloService方法返回");
                return say;
            }
        };
        LOGGER.info(Thread.currentThread().getName() + " 从helloController方法返回");
        return callable;
    }


    @RequestMapping(value = "testQueueMq",method = RequestMethod.POST)
    public void testMq(@RequestBody String message){
        producer.sendQueueMessage(message);
    }

    @RequestMapping(value = "testTopicMq",method = RequestMethod.POST)
    public void testTopicMq(@RequestBody String message) {
        producer.sendTopicMessage(message);
    }

}
