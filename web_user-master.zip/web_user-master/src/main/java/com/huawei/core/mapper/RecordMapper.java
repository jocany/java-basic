package com.huawei.core.mapper;

import com.huawei.core.domain.Record;

import java.util.List;

/********************************************
 * @author: zhang
 * @Description: com.huawei.core.mapper
 * @Date: 下午 9:19 2018/7/4 0004
 * @Modified By:
 ********************************************/
public interface RecordMapper {
    List<Record> selectCategory();
    List<Record> selectRecord();
}
