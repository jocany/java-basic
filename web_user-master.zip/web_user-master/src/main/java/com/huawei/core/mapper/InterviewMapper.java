package com.huawei.core.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.huawei.core.domain.Interview;

public interface InterviewMapper
{
    int add(Interview interview);
    boolean deleteById(Integer id);
    List<Interview> getAll(@Param("pageSize") int pageSize,@Param("start") int start);
}
