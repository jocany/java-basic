package com.huawei.core.domain;

import java.util.Date;

/********************************************
 * @author: zhang
 * @Description: com.huawei.core.domain
 * @Date: 上午 12:25 2018/6/13 0013
 * @Modified By:
 ********************************************/
public class User {

    private Integer id;
    private String nickName;
    private String userName;
    private String password;
    private Date createTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Date getCreateTime()
    {
        return createTime;
    }

    public void setCreateTime(Date createTime)
    {
        this.createTime = createTime;
    }
}
