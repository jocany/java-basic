package com.huawei.core.controller;

import com.huawei.core.domain.User;
import com.huawei.core.service.UserService;
import com.huawei.core.util.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/********************************************
 * @author: zhang
 * @Description: com.green.user.web_user.controller
 * @Date: 上午 12:54 2018/6/3 0003
 * @Modified By:
 ********************************************/
@RestController
@RequestMapping(value = "core")
public class UserController {

    private static final Logger LOGGER = Logger.getLogger(UserController.class);
    @Autowired
    private UserService userService;

    @RequestMapping(value = "translate")
    public ResponseUtil translate(@RequestParam("word") String word, HttpServletResponse response){
        LOGGER.debug("in translate");
        response.addHeader("Access-Control-Allow-Origin","*");
        if (StringUtil.isEmpty(word)){
            return new ResponseParam();
        }
        String result = userService.translate(word);
        if (StringUtil.isEmpty(result)){
            return new ResponseFailed();
        }
        return new ResponseSuccess(result);
    }

    @RequestMapping("users")
    public List<User> getAll(){
        return userService.getAll();
    }

    @RequestMapping(value = "user",method = RequestMethod.POST)
    public ResponseUtil addUser(@RequestBody User user){
        userService.addUser(user);
        return new ResponseSuccess("null");
    }
    
    @RequestMapping(value="user/{id:.*}",method=RequestMethod.DELETE)
    public ResponseUtil deleteUser(@PathVariable String id) {
        return userService.deleteUser(id);
    }
    
    @RequestMapping(value="user/{id:.*}",method=RequestMethod.PUT)
    public ResponseUtil updateUser(@PathVariable("id")int id,@RequestBody User  user) {
        return userService.updateUser(id,user);
    }
}
