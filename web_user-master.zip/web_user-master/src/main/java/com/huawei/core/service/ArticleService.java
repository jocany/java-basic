package com.huawei.core.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huawei.core.domain.Article;
import com.huawei.core.mapper.ArticleMapper;
import com.huawei.core.util.ResponseUtil;

@Service
public class ArticleService
{
    @Autowired
    private ArticleMapper articleMapper;
    public ResponseUtil add(Article article) {
        article.setCreateTime(new Date());
        return new ResponseUtil(200, "success", articleMapper.add(article));
    }
    
    public ResponseUtil findAll() {
        return new ResponseUtil(200, "success", articleMapper.findAll());
    }
}
