package com.huawei.core.mq;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.stereotype.Service;

import javax.jms.Queue;
import javax.jms.Topic;

/********************************************
 * @author: zhang
 * @Description: com.huawei.core.mq
 * @Date: 下午 11:55 2018/8/8 0008
 * @Modified By:
 ********************************************/
@Service
public class Producer {
    @Autowired
    private JmsMessagingTemplate jmsMessagingTemplate;

    @Autowired
    private Topic topic;

    @Autowired
    private Queue queue;

    public void sendQueueMessage(final String message){
        jmsMessagingTemplate.convertAndSend(queue,message);


    }

    public void sendTopicMessage(final String message){

        jmsMessagingTemplate.convertAndSend(topic,message);

    }
}
