package com.huawei.core.controller;

import com.huawei.core.service.TaskService;
import com.huawei.core.task.TaskScheduler;
import com.huawei.core.util.ResponseUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/********************************************
 * @author: zhang
 * @Description: com.huawei.core.controller
 * @Date: 上午 12:14 2018/8/3 0003
 * @Modified By:
 ********************************************/
@RestController
@RequestMapping(value = "core")
public class TaskController {

    @Autowired
    private TaskService taskService;
    @RequestMapping(value = "submitTask",method = RequestMethod.POST)
    public ResponseUtil scheduler(@RequestBody TaskScheduler taskScheduler){
        return taskService.add(taskScheduler);
    }
}
