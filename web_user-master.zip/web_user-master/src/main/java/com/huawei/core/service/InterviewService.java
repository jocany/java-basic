package com.huawei.core.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huawei.core.domain.Interview;
import com.huawei.core.mapper.InterviewMapper;
import com.huawei.core.util.ResponseFailed;
import com.huawei.core.util.ResponseSuccess;
import com.huawei.core.util.ResponseUtil;

@Service
public class InterviewService
{
    @Autowired
    private InterviewMapper interviewMapper;
    
    public ResponseUtil addInterview(Interview interview) {
        interview.setCreateTime(new Date());
        int interviewRtr = interviewMapper.add(interview);
        System.out.println(interview);
        if(interviewRtr > 0) {
            return new ResponseSuccess(interview.getId());
        }
        return new ResponseFailed();
    }
    
    public ResponseUtil getInterviews(int pageSize,int currentPage) {
        List<Interview> interviewRtrs = interviewMapper.getAll(pageSize,(currentPage -1 )*pageSize);
        if(null == interviewRtrs) {
            return new ResponseFailed();
        }
        return new ResponseSuccess(interviewRtrs);
    }
    
    public ResponseUtil deleteInterviews(Integer id) {
        boolean result = interviewMapper.deleteById(id);
        if(!result) {
            return new ResponseFailed();
        }
        return new ResponseSuccess(result);
    }
}
