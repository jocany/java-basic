package com.huawei.core.mapper;

import com.huawei.core.domain.Blog;


public interface BlogMapper
{
    boolean add(Blog blog);
}
