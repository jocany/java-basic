package com.huawei.core.util;

/********************************************
 * @author: zhang
 * @Description: com.green.user.web_user.util
 * @Date: 上午 1:36 2018/6/3 0003
 * @Modified By:
 ********************************************/
public class StringUtil {
    public static boolean isEmpty(String string){
        if (null == string || "".equals(string.trim()))
            return true;
        return false;
    }
}
