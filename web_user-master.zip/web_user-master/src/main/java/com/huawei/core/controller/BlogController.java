package com.huawei.core.controller;

public class BlogController
{
    
}
