package com.huawei.core.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.huawei.core.domain.Article;
import com.huawei.core.service.ArticleService;
import com.huawei.core.util.ResponseUtil;

@RestController
@RequestMapping("core")
public class ArticleController
{

    @Autowired
    private ArticleService articleService;
    
    @RequestMapping(value="v1/article",method=RequestMethod.POST)
    public ResponseUtil writeArticle(@RequestBody Article article) {
        return articleService.add(article);
    }
    
    @RequestMapping(value="v1/articles",method=RequestMethod.GET)
    public ResponseUtil getInterviews() {
        return articleService.findAll();
    }
}
