package com.huawei.core.mq;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

/********************************************
 * @author: zhang
 * @Description: com.huawei.core.mq
 * @Date: 下午 11:58 2018/8/8 0008
 * @Modified By:
 ********************************************/
@Component
public class Consumer {
    @JmsListener(destination = "sample.queue")
    public void receiveQueue(String text){
        System.out.println("Consumer1收到的报文为:"+text);
    }
}
