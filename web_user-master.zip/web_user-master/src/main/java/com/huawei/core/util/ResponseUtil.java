package com.huawei.core.util;


/********************************************
 * @author: zhang
 * @Description: com.green.user.web_user.util
 * @Date: 上午 1:22 2018/6/3 0003
 * @Modified By:
 ********************************************/
public class ResponseUtil {

    private int code;
    private String message;
    private Object data;

    public  ResponseUtil(int code,String message){
        this.code = code;
        this.message = message;
    }
    public ResponseUtil(int code,String message,Object data){
        this.code = code;
        this.message = message;
        this.data = data;
    }
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ResponseUtil{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }
}
