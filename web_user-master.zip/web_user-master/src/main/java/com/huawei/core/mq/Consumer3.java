package com.huawei.core.mq;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

/********************************************
 * @author: zhang
 * @Description: com.huawei.core.mq
 * @Date: 上午 12:26 2018/8/9 0009
 * @Modified By:
 ********************************************/
@Component
public class Consumer3 {
    @JmsListener(destination = "sample.topic")
    public void receiveTopic(String text){
        System.out.println("Consumer3收到的topic报文为:"+text);
    }
}
