package com.huawei.core.mq;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

/********************************************
 * @author: zhang
 * @Description: com.huawei.core.mq
 * @Date: 上午 12:00 2018/8/9 0009
 * @Modified By:
 ********************************************/
@Component
public class Consumer2 {
    @JmsListener(destination = "sample.topic")
    public void receiveTopic(String text){
        System.out.println("Consumer2收到的报文为:"+text);
    }
}
