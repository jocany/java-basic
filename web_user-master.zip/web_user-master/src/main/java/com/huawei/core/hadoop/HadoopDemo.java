package com.huawei.core.hadoop;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.io.IOUtils;

import java.io.IOException;
import java.net.URI;

import static org.apache.hadoop.fs.FileSystem.*;

/********************************************
 * @author: zhang
 * @Description: com.green.user.hadoop
 * @Date: 下午 11:06 2018/6/8 0008
 * @Modified By:
 ********************************************/
public class HadoopDemo {

    public static void main(String[] args) throws IOException, InterruptedException {
        String uri="hdfs://192.168.1.4:9000/user/hadoop/dir2/test.txt";
        Configuration configuration=new Configuration();
        FileSystem fileSystem= get(URI.create(uri), configuration,"root");
        FSDataInputStream in = fileSystem.open(new Path(uri));
        IOUtils.copyBytes(in, System.out, 4096, false);
        IOUtils.closeStream(in);
    }
}
  