package com.huawei.core.mapper;

import com.huawei.core.domain.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/********************************************
 * @author: zhang
 * @Description: com.green.user.mapper
 * @Date: 下午 11:35 2018/6/12 0012
 * @Modified By:
 ********************************************/
public interface UserMapper {

    List<User> getAll();

    boolean addUser(@Param("user") User user);
    
    boolean deleteUser(@Param("id") String userID);
    
    boolean updateUser(@Param("user") User user);

}
