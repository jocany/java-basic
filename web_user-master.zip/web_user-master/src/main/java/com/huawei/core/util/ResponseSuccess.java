package com.huawei.core.util;

/********************************************
 * @author: zhang
 * @Description: com.green.user.web_user.util
 * @Date: 上午 1:25 2018/6/3 0003
 * @Modified By:
 ********************************************/
public class ResponseSuccess extends ResponseUtil {
    private static final int STATUS_SUCCESS = 200;

    private static final String MESSAGE_SUCCESS = "success";
    public ResponseSuccess(Object data) {
        super(STATUS_SUCCESS, MESSAGE_SUCCESS, data);
    }
}
