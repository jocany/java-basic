package com.huawei.core.service;

import com.huawei.core.configuration.Env;
import com.huawei.core.mapper.UserMapper;
import com.huawei.core.util.ResponseFailed;
import com.huawei.core.util.ResponseSuccess;
import com.huawei.core.util.ResponseUtil;
import com.huawei.core.domain.User;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.Date;
import java.util.List;

/********************************************
 * @author: zhang
 * @Description: com.green.user.web_user.service
 * @Date: 上午 1:15 2018/6/3 0003
 * @Modified By:
 ********************************************/
@Transactional
@Service
public class UserService {

    private static final Logger LOGGER = Logger.getLogger(UserService.class);
    
    public static final String url = "http://fanyi.youdao.com/openapi.do?keyfrom=neverland&key=969918857&type=data&doctype=json&version=1.1&q=";
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private Env user;

    @Autowired
    private UserMapper userDao;

    public String translate(String string){
        LOGGER.info("in service translate" + user);
        ResponseEntity<String> res = restTemplate.getForEntity(url + string,String.class);
        if (res.getStatusCode().value() == 200){
            return res.getBody();
        }
        return null;
    }

    @Transactional
    public List<User> getAll(){
        return userDao.getAll();
    }

    @Transactional
    public boolean addUser(User user){
        user.setCreateTime(new Date());
        return userDao.addUser(user);
    }

    
    public ResponseUtil deleteUser(String id) {
        boolean result  = userDao.deleteUser(id);
        if(result) {
            return new ResponseSuccess("deleteSuccess");
        }
        return new ResponseFailed();
    }
    
    public ResponseUtil updateUser(int id,User user) {
        user.setId(id);
        boolean result  = userDao.updateUser(user);
        if(result) {
            return new ResponseSuccess("updateSuccess");
        }
        return new ResponseFailed();
    }

}
