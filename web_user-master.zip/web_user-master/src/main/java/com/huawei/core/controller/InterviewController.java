package com.huawei.core.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huawei.core.domain.Interview;
import com.huawei.core.service.InterviewService;
import com.huawei.core.util.ResponseUtil;

@RestController
@RequestMapping(value = "core")
public class InterviewController
{
    @Autowired
    private InterviewService interviewService;
    
    @RequestMapping(value="interview",method=RequestMethod.POST)
    public ResponseUtil addInterview(@RequestBody Interview interview) {
        return interviewService.addInterview(interview);
    }
    
    @RequestMapping(value="interviews",method=RequestMethod.GET)
    public ResponseUtil getInterviews(@RequestParam("pageSize") int pageSize,@RequestParam("currentPage") int currentPage) {
        return interviewService.getInterviews(pageSize,currentPage);
    }
    
    @RequestMapping(value="interview/{id:.*}",method=RequestMethod.DELETE)
    public ResponseUtil deleteInterview(@PathVariable int id) {
        return interviewService.deleteInterviews(id);
    }
}
