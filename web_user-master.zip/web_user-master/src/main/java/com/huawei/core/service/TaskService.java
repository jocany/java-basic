package com.huawei.core.service;

import com.huawei.core.task.TaskScheduler;
import com.huawei.core.util.ResponseSuccess;
import com.huawei.core.util.ResponseUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/********************************************
 * @author: zhang
 * @Description: com.huawei.core.service
 * @Date: 上午 12:03 2018/8/3 0003
 * @Modified By:
 ********************************************/
@Service
public class TaskService {

    private volatile HashMap<String,ScheduledFuture<String>> tasks = new HashMap<>();
    @Autowired
    private ScheduledThreadPoolExecutor pool;

    public synchronized ResponseUtil add(TaskScheduler taskScheduler){
        //如果任务队列不存在任务直接跳过，不存在取消任务的情况
        if (!tasks.isEmpty()){
            ScheduledFuture<String> task = tasks.get(taskScheduler.getTaskId());
            if (task != null) {
                boolean result = task.cancel(true);
                System.out.println("取消任务的ID：" + taskScheduler.getTaskId() + " 结果: " + result);
            }
        }
        ScheduledFuture<String> scheduledFuture = pool.schedule(taskScheduler,taskScheduler.getNum(), TimeUnit.MICROSECONDS);
        tasks.put(taskScheduler.getTaskId(),scheduledFuture);
        return new ResponseSuccess("添加任务成功");
    }
}
