package com.huawei.core.mapper;

import java.util.List;


import com.huawei.core.domain.Article;

public interface ArticleMapper
{
    Integer add(Article article);
    
    
    List<Article> findAll();
}
