package com.huawei.core.domain;

import java.util.List;

/********************************************
 * @author: zhang
 * @Description: com.huawei.core.domain
 * @Date: 下午 9:05 2018/7/4 0004
 * @Modified By:
 ********************************************/
public class Record {

    private String parentID;
    private String categoryID;
    private String title;
    private String pipelineID;
    private String name;
    private String link;

    private String type;

    private List<Record> child;

    public String getParentID() {
        return parentID;
    }

    public void setParentID(String parentID) {
        this.parentID = parentID;
    }

    public String getCategoryID() {
        return categoryID;
    }

    public void setCategoryID(String categoryID) {
        this.categoryID = categoryID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPipelineID() {
        return pipelineID;
    }

    public void setPipelineID(String pipelineID) {
        this.pipelineID = pipelineID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<Record> getChild() {
        return child;
    }

    public void setChild(List<Record> child) {
        this.child = child;
    }

    @Override
    public String toString() {
        return "Record{" +
                "parentID='" + parentID + '\'' +
                ", categoryID='" + categoryID + '\'' +
                ", title='" + title + '\'' +
                ", pipelineID='" + pipelineID + '\'' +
                ", name='" + name + '\'' +
                ", link='" + link + '\'' +
                ", type='" + type + '\'' +
                ", child=" + child +
                '}';
    }
}
