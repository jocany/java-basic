package com.huawei.core.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

/********************************************
 * @author: zhang
 * @Description: com.green.user.configuration
 * @Date: 下午 10:22 2018/6/12 0012
 * @Modified By:
 ********************************************/
@Component
@ConfigurationProperties(prefix = "hello")//这里的hello对应的就是my.properties里的属性前缀
@PropertySource("classpath:config/env.properties")//这是属性文件路径
public class Env {
    private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return "Env{" +
                "text='" + text + '\'' +
                '}';
    }
}
