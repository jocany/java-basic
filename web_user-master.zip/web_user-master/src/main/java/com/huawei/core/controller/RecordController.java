package com.huawei.core.controller;

import com.huawei.core.domain.Record;
import com.huawei.core.service.RecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/********************************************
 * @author: zhang
 * @Description: com.huawei.core.controller
 * @Date: 下午 9:24 2018/7/4 0004
 * @Modified By:
 ********************************************/
@RestController
public class RecordController {

    @Autowired
    private RecordService recordService;

    @RequestMapping("getAll")
    public List<Record> getAll(){
        return recordService.getAll();
    }
}
