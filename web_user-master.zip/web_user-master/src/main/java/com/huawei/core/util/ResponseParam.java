package com.huawei.core.util;

/********************************************
 * @author: zhang
 * @Description: com.green.user.web_user.util
 * @Date: 上午 1:30 2018/6/3 0003
 * @Modified By:
 ********************************************/
public class ResponseParam extends ResponseUtil{
    private static final int STATUS_INVALID = 403;

    private static final String MESSAGE_INVALID = "params error request!";
    public ResponseParam() {
        super(STATUS_INVALID, MESSAGE_INVALID);
    }
}
