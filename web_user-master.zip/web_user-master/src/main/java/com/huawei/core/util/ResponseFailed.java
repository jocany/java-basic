package com.huawei.core.util;

/********************************************
 * @author: zhang
 * @Description: com.green.user.web_user.util
 * @Date: 上午 1:28 2018/6/3 0003
 * @Modified By:
 ********************************************/
public class ResponseFailed extends ResponseUtil{
    private static final int STATUS_FAILED = 503;

    private static final String MESSAGE_FAILED = "failed,error request!";
    public ResponseFailed() {
        super(STATUS_FAILED, MESSAGE_FAILED);
    }
}
