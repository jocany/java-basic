package com.huawei.core.task;

import java.util.concurrent.Callable;

public class TaskScheduler implements Callable<String>
{
    private String taskId;
    
    private Integer num;

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public TaskScheduler(){}
    public TaskScheduler(String taskId, Integer num) {
        this.taskId = taskId;
        this.num = num;
    }
    
    @Override
    public String call() throws Exception
    {
        for(int i = 0; i < num;i++) {
            Thread.sleep(i*1000);
            System.out.println(taskId + "  " + i);
        }
        return taskId + " " + num;
    }

}
