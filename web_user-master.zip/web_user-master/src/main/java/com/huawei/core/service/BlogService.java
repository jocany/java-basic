package com.huawei.core.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.huawei.core.domain.Blog;
import com.huawei.core.mapper.BlogMapper;
import com.huawei.core.util.ResponseFailed;
import com.huawei.core.util.ResponseSuccess;
import com.huawei.core.util.ResponseUtil;

public class BlogService
{
    @Autowired
    private BlogMapper blogMapper;
    
    public ResponseUtil addBlog(Blog blog) {
        if(blogMapper.add(blog)) {
            return new ResponseSuccess(blog);
        }
        return new ResponseFailed();
    }
}
