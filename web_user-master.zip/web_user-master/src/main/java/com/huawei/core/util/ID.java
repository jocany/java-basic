package com.huawei.core.util;

import java.util.UUID;

/********************************************
 * @author: zhang
 * @Description: com.huawei.core.util
 * @Date: 上午 12:09 2018/6/29 0029
 * @Modified By:
 ********************************************/
public class ID {
    public static String generateID(){
        String uuid = UUID.randomUUID().toString();
        return uuid.replaceAll("-","");
    }

    public static void main(String[] args) {
        System.out.println(generateID());
    }
}
