## es6-webpack

### 安装

首先下载源码

```shell
git clone https://github.com/cucygh/es6-webpack.git
```

然后安装

```shell
npm i
npm i webpack -g
npm i webpack-dev-server -g
```

### 运行

```shell
npm start
```
