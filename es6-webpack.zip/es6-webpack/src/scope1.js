/*
ES5中的作用域
*/
var callbacks=[];
//在循环中var i=0时有“变量提升”的效果
for(var i=0;i<=2;i++){
	callbacks[i]=function(){
		//注意：i*2中的i是对变量的引用而不是对变量值的引用
		return i*2;
	}
}
console.table([
	callbacks[0](),
	callbacks[1](),
	callbacks[2]()
	]);

/*
ES6中的作用域
*/

const callbacks2=[];
//使用let声明的变量会有块作用域的概念
for(let j=0;j<=2;j++){
	callbacks2[j]=function(){
		return j*2;
	}
}

console.table([
	callbacks2[0](),
	callbacks2[1](),
	callbacks2[2]()
	]);

//使用立即执行函数，可以让在此块中声明的函数只能在该块中执行
(function(){
	const foo=function(){
		return 1;
	}
	console.log("foo()===1:"+(foo()===1));
	//在内部又声明一个立即执行函数
	(function(){
		const foo=function(){
			return 2;
		}
		console.log("foo()===2:"+(foo()===2));
	})();
})();

//ES6中语法，使用{ }
{
	const foo=function(){
		return 1;
	}
	console.log("ES6:foo()===1:"+(foo()===1));
	{
		const foo=function(){
			return 2;
		}
		console.log("ES6:foo()===2:"+(foo()===2));
	}
}