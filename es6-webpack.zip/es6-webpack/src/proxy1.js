//对象代理
{
	//ES3 ES5中进行数据保护
	var Person=function(){
		var data={
			name:'xiaoming',
			age:18,
			sex:'male'
		}
		this.get=function(key){
			return data[key];
		}
		this.set=function(key,value){
			if(key!='sex'){
				data[key]=value;
			}
		}
	}
	var person=new Person();
	console.group("人物信息：");
	console.log(person.get("name"));
	person.set("name","xiaohua");
	console.log(person.get("name"));
	person.set("sex","female");
	console.log(person.get("sex"));
}
{
	//ES6中通过对象代理进行数据保护
	let Person={
		name:"xiaowang",
		age:18,
		sex:'male'
	};

	var validate={
		get:function(target,key){
			return target[key];
		},
		set:function(target,key,value){
			if(key=='sex'){
				throw new Error("Gender cannot be modified!");
				return false;
			}
			target[key]=value;
	        return true;
			
		}
	}

    //person就会代理Person,此person是暴露给用户的对象
	let person=new Proxy(Person,validate);
    console.group("ES6 人物信息：");
	console.log(person.name);
	person.name="xiaohua";
	console.log(person.name);
	person.sex="female";
	console.log(person.sex);

}