/*
*  正则的扩展
*/
{
    /*
     u修饰符
     含义为“Unicode 模式”，用来正确处理大于\uFFFF的 Unicode 字符。
     也就是说，会正确处理四个字节的 UTF-16 编码。
     */

    console.log(/^\uD83D/u.test('\uD83D\uDC2A'));
    console.log(/^\uD83D/.test('\uD83D\uDC2A'));


    console.log(/\u{61}/.test('a'));
    console.log(/\u{61}/u.test('a'));
    console.log(/\u{20BB7}/u.test('𠮷'));
}

{
    //求字符串的长度
    function codePointLength(text) {
        var result = text.match(/[\s\S]/gu);
        return result ? result.length : 0;
    }
    var s = '𠮷𠮷';

   console.log(s.length);
   console.log(codePointLength(s));
}
{
    //RegExp.prototype.unicode属性
    const r1 = /hello/;
    const r2 = /hello/u;
    console.group({1:r1.unicode,2:r2.unicode});

}
{
    //y修饰符
    var str = 'aaa_aa_a';
    var r1 = /a+/g;
    var r2 = /a+/y;
    console.log(r1.exec(str));
    console.log(r1.exec(str));
    console.log(r1.exec(str));

    console.log(r2.exec(str));
    console.log(r2.exec(str));
}