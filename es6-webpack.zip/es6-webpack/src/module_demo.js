/*
Module
 */
/*export var firstName = 'Michael';
export var lastName = 'Jackson';
export var year = 1958;*/

    var firstName = 'Michael';
    var lastName = 'Jackson';
    var year = 1958;
    export {firstName, lastName, year};

export function multiply(x, y) {
    return x * y;
};

function v1() {  }
function v2() {  }

export {
    v1 as streamV1,
    v2 as streamV2
};

export var obj={}

export function area(radius) {
    return Math.PI * radius * radius;
}

export function circumference(radius) {
    return 2 * Math.PI * radius;
}