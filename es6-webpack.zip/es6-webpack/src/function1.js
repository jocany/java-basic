//箭头函数
/*
语法：(参数)=>{代码}

*/

{
	//ES5
	var events=[1,2,3,4,5,6];
	var odds=events.map(function(v){
           return v+1;
	});
	console.log(events+"-----"+odds);
}
{
	//ES6
	const events=[1,2,3,4,5,6];
	const odds=events.map(v=>v+1);
	console.log(events+"-----"+odds);
}
{
	//this指向的问题
	//ES3 ES5中this指向该函数被调用的对象
	var factory=function(){
		this.a="a";
		this.b="b";
		this.c={
			a:"a+",
			b:function(){
				return this.a;
			}
		}
	}
	console.log(new factory().c.b());

}
{
	//ES6中指this向定义时this的指向
	var factory=function(){
		this.a="a";
		this.b="b";
		this.c={
			a:"a+",
			b:()=>this.a
			
		}
	}
	console.log(new factory().c.b());
}