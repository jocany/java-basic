/*
 Set 数据结构
*/
{
    //基本用法
    const fruits = new Set();
    ["orange","apple","watermelon","pineapple","apple"].forEach(f=>fruits.add(f));
    for(let f of fruits){
        console.log(f);
    }
}
{
    // 将数组转为Set集合
    const fruits = new Set(["orange", "apple", "watermelon", "pineapple", "apple"]);
    console.log(fruits.size);
    // 将set集合转为数组
    console.log([...fruits]);
}
{
    let set = new Set();
    let a = NaN;
    let b = NaN;
    set.add(a);
    set.add(b);
    console.log(set);
}
{
    //set集合的属性和方法
    const set = new Set();
    set.add(1).add(5).add(2);
    let size =set.size;
    console.log(`set集合的大小是:${size}`);
    set.delete(1);
    console.log(set.has(1));
    set.clear();//清空Set
    console.log(set.size);

}
{
    //使用Array.from()将Set转为Array
    const items = new Set([1, 2, 3, 4, 5]);
    const array = Array.from(items);
    for(let num of array){
        console.log(num);
    }
}
{
    function dedupe(array) {
        return Array.from(new Set(array));
    }
    console.log(dedupe([1, 1, 2, 3]));
}
{
    let set = new Set(['red', 'green', 'blue']);
    for (let item of set.keys()) {
        console.log(item);
    }

    for (let item of set.values()) {
        console.log(item);
    }

    for (let item of set.entries()) {
        console.log(item);
    }

    for(let item of set){
        console.log(item);
    }
}
{
    let set = new Set([1, 4, 9]);
    set.forEach((value, key) => console.log(key + ' : ' + value))
}