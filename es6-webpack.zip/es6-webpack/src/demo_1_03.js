{
    //字符串的遍历器接口  for...of
    let str="hello";
    for(let ch of str){
        console.log(ch);
    }

    let text = String.fromCodePoint(0x20BB7);

    for (let i = 0; i < text.length; i++) {
        console.log(i+"---"+text[i]);
    }


    for (let i of text) {
        console.log(i);
    }

}

{
    //includes(), startsWith(), endsWith()
    let s = 'Hello world!';

    console.log(s.startsWith('Hello'));
    console.log(s.endsWith('!'));
    console.log(s.includes('o'));

    //从索引为6的位置开始搜索
    console.log(s.startsWith('world',6));
    //针对前5个字符
    console.log(s.endsWith('Hello',5));
    //从索引为6的位置开始搜索
    console.log(s.includes('o',6));
}

{
    //repeat():返回一个新字符串，表示将原字符串重复n次
    console.log('x'.repeat(3));
    console.log('hello'.repeat(2));
    console.log('na'.repeat(0));
}

{
    //padStart()，padEnd()：字符串补全长度
    console.log( 'a'.padStart(5, '*'));
    console.log( 'a'.padStart(4, '*$'));
    console.log('a'.padEnd(5, '*$'));
    console.log( 'a'.padEnd(4, '*$'));
    console.log( 'a'.padStart(4));
    //常见用途 1：为数值补全指定位数
    let num = '123456'.padStart(10, '0')
    console.log(num);
    //常见用途 2:提示字符串格式
    let date = '03-10'.padStart(10, 'YYYY-MM-DD')
    console.log(date);
}
{
    //模板字符串

    // 普通字符串
    let normal = `In JavaScript '\n' is a line-feed.`;

   // 多行字符串
     let multi =  `In JavaScript this is
        not legal.`;

    // 字符串中嵌入变量
    let name = "Bob", time = "today";
    let nt = `Hello ${name}, how are you ${time}?`;
    console.log(`${normal}---${multi}---${nt}`);
}

{
    //${}中可以放入任意的 JavaScript 表达式，可以进行运算，以及引用对象属性。
    let x = 1;
    let y = 2;
    console.log(`${x}+${y}=${x+y}`);
    let obj = {x: 10, y: 20};
    console.log(`${obj.x + obj.y}`);

    //模板字符串还能调用函数
    function fn() {
        return "Hello World";
    }
    console.log(`foo ${fn()} bar`);
}
{
    //如果需要引用模板字符串本身，在需要时执行，可以像下面这样写。

    /*let str = 'return ' + '`Hello ${name}!`';
    let func = new Function('name', str);*/


    let str = '(name) => `Hello ${name}!`';
    let func = eval.call(null, str);
    let result = func('Jack')
    console.log(result);
}

{

    //标签模板
   /* alert`hello`*/
    //等同于alert('hello');

    let type = "AK47";
    let color = "black";
    tag`1'm using ${type},color is ${color}`;
    //等同于tag(["1'm using ",",color is ",""],"AK47","black")
    function tag(s, v1, v2) {
        console.table({raw:s.raw})
        console.log(s[0]);
        console.log(s[1]);
        console.log(s[2]);
        console.log(v1);
        console.log(v2);
    }

    let total = 30;
    let msg = passthru`The total is ${total} (${total*1.05} with tax)`;
    /*function passthru(literals) {
        let result = '';
        let i = 0;
        while (i < literals.length) {
            result += literals[i++];
            if (i < arguments.length) {
                result += arguments[i];
            }
        }
        return result;
    }*/
    function passthru(literals, ...values) {
        let output = "";
        let index;
        for (index = 0; index < values.length; index++) {
            output += literals[index] + values[index];
        }
        output += literals[index]
        return output;
    }
    console.log(msg)

}

{
    //“标签模板”的一个重要应用，就是过滤 HTML 字符串，防止用户输入恶意内容
    function SaferHTML(templateData) {
        let s = templateData[0];
        for (let i = 1; i < arguments.length; i++) {
            let arg = String(arguments[i]);

            // Escape special characters in the substitution.
            s += arg.replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;");

            // Don't escape special characters in the template.
            s += templateData[i];
        }
        return s;
    }
    let sender = '<script>alert("abc")</script>'; // 恶意代码
    let message = SaferHTML`<p>${sender} has sent you a message.</p>`;
    console.log(message)

}

{
    //模板处理函数的第一个参数（模板字符串数组），还有一个raw属性
    let type = "AK47";
    tag`1'm using ${type}`;

    tag`hello\nworld!`

    function tag(s, ...vaule) {
        console.table({raw:s.raw},{s:s})
    }
}

{
    let str = String.raw`Hi\n${2+3}`;
    console.log(str)

    let str2 = String.raw({ raw: 'test' }, 0, 1, 2);
    console.log(str2)
}

