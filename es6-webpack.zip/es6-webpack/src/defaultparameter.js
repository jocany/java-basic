//默认参数
{
	//ES3 ES5中的实现,如果参数比较多时，显得比较麻烦
	function sum(x,y,z){
		if(y==undefined){
			y=7;
		}
		if(z==undefined){
			z=40;
		}
		return x+y+z;
	}
	console.log("ES5:"+sum(1));
}

{
	//ES6中的实现
	function sum(x,y=7,z=40){
		return x+y+z;
	}
	console.log("ES6:"+sum(1,10));
}


{
	//在上面，如果x不填写，也会出现问题，利用默认参数可以解决
	function checkNecessary(){
		throw new Error("can\'t is empty!");
	}
	function sum(x=checkNecessary(),y=7,z=40){
		return x+y+z;
	}
	console.log("ES6:"+sum(1));
	/*try{
		console.log(sum());
	}catch(e){
		console.log(e);
	}finally{

	}*/
}
{
	//可变参数
	//ES3 ES5中的处理
	function abc(){
		//Array.prototype.slice.call(arguments)的作用为：强制转化arguments为数组格式
		/*
		Array.prototype.slice.call(arguments)
		等价于[].slice.call(arguments)
		因为，前面的调用者的作用只是沿着原型链向上找，最终找到Array为止，slice为Array原型上的一个方法
		*/
		var arr=[].slice.call(arguments);
		var sum=0;
		arr.forEach(function(v){
			sum+=v;
		});
		return sum;
	}

	console.log("ES5 可变参数："+abc(1,2,3,4,5));

}

{
	//ES6中处理可变参数
	function abc(...arr){
		let sum=0;
		arr.forEach(item=>sum+=item);
		return sum;
	}
	console.log("ES6 可变参数："+abc(1,2,3,4));
}
{
	//使用扩展运算符合并数组
	var params=["hello",true,7];
	var others=[1,2,...params];
	console.log(others);
}