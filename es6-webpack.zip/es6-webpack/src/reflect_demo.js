/*
reflect
 */
{
    var loggedObj = new Proxy({}, {
        get(target, name) {
            console.log('get', target, name);
            return Reflect.get(target, name);
        },
        deleteProperty(target, name) {
            console.log('delete' + name);
            return Reflect.deleteProperty(target, name);
        },
        has(target, name) {
            console.log('has' + name);
            return Reflect.has(target, name);
        }
    });

}
{
    var myObject = {
        foo: 1,
        bar: 2,
        get baz() {
            return this.foo + this.bar;
        },
    }

    Reflect.get(myObject, 'foo') // 1
    Reflect.get(myObject, 'bar') // 2
    Reflect.get(myObject, 'baz') // 3
}
{
    var myObject = {
        foo: 1,
        bar: 2,
        get baz() {
            return this.foo + this.bar;
        },
    };

    var myReceiverObject = {
        foo: 4,
        bar: 4,
    };
    console.log(Reflect.get(myObject, 'baz', myReceiverObject));
}
{
    //Reflect.get(1,'foo');
    var myObject = {
        foo: 1,
        set bar(value) {
            return this.foo = value;
        },
    }
    console.log(myObject.foo);
    Reflect.set(myObject, 'foo', 2);
    console.log(myObject.foo);
    Reflect.set(myObject, 'bar', 3)
    console.log(myObject.foo);
}
{
    var myObject = {
        foo: 4,
        set bar(value) {
            return this.foo = value;
        },
    };

    var myReceiverObject = {
        foo: 0,
    };

    Reflect.set(myObject, 'bar', 1, myReceiverObject);
    console.log(myObject.foo);
    console.log(myReceiverObject.foo);
}
{
    var myObject = {
        foo: 1,
    };
// 旧写法
    'foo' in myObject // true
// 新写法
    Reflect.has(myObject, 'foo') // true
}
{
    const myObj = { foo: 'bar' };
// 旧写法
    delete myObj.foo;
// 新写法
    Reflect.deleteProperty(myObj, 'foo');
}
{
    function Greeting(name) {
        this.name = name;
    }
// new 的写法
    const instance1 = new Greeting('张三');
// Reflect.construct 的写法
    const instance2 = Reflect.construct(Greeting, ['张三']);
}
{
    function FancyThing(){};
    const myObj = new FancyThing();
// 旧写法
    Object.getPrototypeOf(myObj) === FancyThing.prototype;

// 新写法
    Reflect.getPrototypeOf(myObj) === FancyThing.prototype;
}
{
    var myObject = {};
    Object.defineProperty(myObject, 'hidden', {
        value: true,
        enumerable: false,
    });

// 旧写法
    var theDescriptor = Object.getOwnPropertyDescriptor(myObject, 'hidden');

// 新写法
    var theDescriptor = Reflect.getOwnPropertyDescriptor(myObject, 'hidden');
}
{
    var myObject = {
        foo: 1,
        bar: 2,
        [Symbol.for('baz')]: 3,
        [Symbol.for('bing')]: 4,
    };

    // 旧写法
    console.log(Object.getOwnPropertyNames(myObject));
    console.log(Object.getOwnPropertySymbols(myObject));
    // 新写法
    console.log(Reflect.ownKeys(myObject));
}