/*
变量的解构赋值
 */

//1 数组的解构
/*{
   //旧的写法
    let a = 1;
    let b = 2;
    let c = 3;
    //解构的方式为变量赋值
    let [a1, b1, c1] =[1, 2, 3];

}*/

//数组中比较复杂的解构
/*{
    let [foo, [[bar], baz]] = [1, [[2], 3]];
    foo // 1
    bar // 2
    baz // 3
    let [ , , third] = ["foo", "bar", "baz"];
    third // "baz"
    let [x, , y] = [1, 2, 3];
    x // 1
    y // 3
    let [head, ...tail] = [1, 2, 3, 4];
    head // 1
    tail // [2, 3, 4]
    let [x, y, ...z] = ['a'];
    x // "a"
    y // undefined
    z // []
}*/

//Set结构，使用数组的解构赋值
{
    let [x, y, z] = new Set(['a', 'b', 'c']);
    console.log(x,y,z);
    //解构赋值允许指定默认值。
    let [foo = true] = [];
    console.log(foo);

    let [name, age= 20] = ['Wan Xiao'];
    console.log(name,age);
    let [un, pas = '123456'] = ['admin', undefined];
    console.log(un,pas);

    function f() {
        console.log('aaa');
    }

    let [fun = f()] = [1];
    console.log(fun);

}
//对象的解构赋值
{
    let { foo, bar } = { foo: "aaa", bar: "bbb" };
    console.log(foo, bar);

    //如果变量名与属性名不一致，必须写成下面这样
    let { foo: baz } = { foo: 'aaa', bar: 'bbb' };
    console.log(baz)

    let obj = { first: 'hello', last: 'world' };
    let { first: f, last: l } = obj;
    console.log(f,l);
}
{
    //与数组一样，解构也可以用于嵌套结构的对象
    /*let obj = {
        p: [
            'Hello',
            { y: 'World' }
        ]
    };


    let { p: [x, { y }] } = obj;
    console.log(x,y);*/
    //对象的解构也可以指定默认值。
    var {x1 = 3} = {};
    console.log(x1);

    var {x2, y2 = 5} = {x2: 1};
    console.log(x2,y2);

    var {x3: y3 = 3} = {};
    console.log(y3);

    var {x4: y4 = 3} = {x4: 5};
   console.log(y4);

    var { message: msg = 'Something went wrong' } = {};
    console.log(msg);
}
{
    //对象的解构赋值，可以很方便地将现有对象的方法，赋值到某个变量
    let { log, sin, cos } = Math;
    console.log(sin(45));

}
{
    //字符串的解构赋值:字符串被转换成了一个类似数组的对象。

    const [a, b, c] = "hello";
    console.log(a,b,c);
    //类似数组的对象都有一个length属性，因此还可以对这个属性解构赋值。
    const {length: len}="hello";
    console.log("'hello'.length:"+len);

}
{
    //数值和布尔值的解构赋值
    let {toString: num} = 123;
    let {toString: bol} = true;
    console.log(num === Number.prototype.toString,bol === Boolean.prototype.toString);

}

{
    //函数参数的解构赋值
    function add([x, y]){
        return x + y;
    }

    console.log(add([1, 2]));

    let newarr = [[1, 2], [3, 4]].map(([a, b]) => a + b);
    console.log(newarr[0],newarr[1]);
}
{
    //函数参数的解构也可以使用默认值。
  /*  function move({x = 0, y = 0} = {}) {
        return [x, y];
    }

    move({x: 3, y: 8}); // [3, 8]
    move({x: 3}); // [3, 0]
    move({}); // [0, 0]
    move(); // [0, 0]*/

    /*function move({x, y} = { x: 0, y: 0 }) {
        return [x, y];
    }

    move({x: 3, y: 8}); // [3, 8]
    move({x: 3}); // [3, undefined]
    move({}); // [undefined, undefined]
    move(); // [0, 0]

    //undefined才会触发函数参数的默认值

    let arr2=[1, undefined, 3].map((x = 10) => x+8);
    arr2.forEach(y=>console.log(y))*/
}
{
    //解构的用途
    //1、交换变量的值
    let x = 1;
    let y = 2;
    [x, y] = [y, x];
    console.log(`x=${x},y=${y}`);
    //2、函数返回多个值
    function example() {
        return [1, 2, 3];
    }
    let [a, b, c] = example();
    console.log(`a=${a},b=${b},c=${c}`);
    //提取 JSON 数据
    let jsonData = {
        id: 42,
        status: "OK",
        data: [867, 5309]
    };

    let { id, status, data: number } = jsonData;

    console.log(id, status, number);
    //函数参数的默认值
    //遍历map
    const map = new Map();
    map.set('first', 'hello');
    map.set('second', 'world');

    for (let [key, value] of map) {
        console.log(key + " is " + value);
    }


}