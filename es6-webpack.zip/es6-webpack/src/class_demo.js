/*
class
 */
{
    const MyClass = class Me {
        getClassName() {
            return Me.name;
        }
    };
    let c =new MyClass();

    console.log(c.getClassName());
}
{
    //采用Class表达式，可以写出立即执行的Class
    let person = new class {
        constructor(name) {
            this.name = name;
        }
        sayName() {
            console.log(this.name);
        }
    }('张三');
    person.sayName();
}
{
  /*  new Foo();
    class Foo {}*/
    class Point {}
    console.log("类名："+Point.name);
}
{
    class Foo {
        constructor(...args) {
            this.args = args;
        }
        * [Symbol.iterator]() {
            for (let arg of this.args) {
                yield arg;
            }
        }
    }

    for (let x of new Foo('hello', 'world')) {
        console.log(x);
    }
}
{
    class Logger {
        constructor() {
            this.printName = ()=>this;
        }
        printName(name = 'there') {
            this.print(`Hello ${name}`);
        }
        print(text) {
            console.log(text);
        }
    }

    const logger = new Logger();
    logger.printName();
    const { printName } = logger;//把printName方法提出来
    printName();
}
{
    //静态方法
    class Foo {
        static classMethod() {
            return 'hello';
        }
    }
    console.log(Foo.classMethod());
    var foo = new Foo();
    //foo.classMethod();//只能通过类名来访问
}
{
    class Foo {
        static classMethod() {
            return 'hello';
        }
    }
    class Bar extends Foo {
    }
    Bar.classMethod()
}
{
    class Foo {
        static classMethod() {
            return 'hello';
        }
    }

    class Bar extends Foo {
        static classMethod() {
            return super.classMethod() + ', too';
        }
    }

    console.log(Bar.classMethod());
}
{
   /* class IncreasingCounter {
        _count = 0;
        get value() {
            console.log('Getting the current value!');
            return this._count;
        }
        increment() {
            this._count++;
        }
    }*/

}
{
    //静态属性
    class Person{
        constructor(){
            //构造函数
        }
    }
    Person.prop="prop";
    console.log(Person.prop);
}
{
    //私有方法和属性
    class Widget {
        // 公有方法
        foo (baz) {
            this._bar(baz);
        }
        // 私有方法
        _bar(baz) {
            return this.snaf = baz;
        }

    }
}
{
    class Widget {
        foo (baz) {
            bar.call(this, baz);
        }
    }

    function bar(baz) {
        return this.snaf = baz;
    }
}
{
    const bar = Symbol('bar');
    const snaf = Symbol('snaf');

  /*  export default class myClass{
        // 公有方法
        foo(baz) {
            this[bar](baz);
        }
        // 私有方法
        [bar](baz) {
            return this[snaf] = baz;
        }
    };*/
}
{
    class Rectangle {
        constructor(length, width) {
            console.log(new.target === Rectangle);
            // ...
        }
    }

    class Square extends Rectangle {
        constructor(length, width) {
            super(length, width);
        }
    }

    var obj = new Square(3);
}
{
    //类的继承
    class Point {
        constructor(x, y){
            this.x=x;
            this.y=y;
        }
        toString(){
            return `x:${this.x},y:${this.y}`;
        }
    }
    class ColorPoint extends Point {
        constructor(x, y, color) {
            super(x, y); // 调用父类的constructor(x, y)
            this.color = color;
        }
        toString() {
            return this.color + ' ' + super.toString(); // 调用父类的toString()
        }
    }
    let cp=new ColorPoint(10,20,"red");
    let result=cp.toString();
    console.log(result);

    console.log(cp instanceof ColorPoint);
    console.log(cp instanceof Point);

    //获取父类
    console.log(Object.getPrototypeOf(cp) );
}
{
    class A {}
    class B extends A {}

    console.log(B.__proto__ === A);
    console.log(B.prototype.__proto__ === A.prototype);
}
{
    class A extends Object {
    }

    console.log(A.__proto__ === Object);
    console.log(A.prototype.__proto__ === Object.prototype);
}

{
    class A {}

    console.log(A.__proto__ === Function.prototype);
    console.log(A.prototype.__proto__ === Object.prototype);
}
{
    class MyArray extends Array {
        constructor(...args) {
            super(...args);
        }
    }

    var arr = new MyArray();
    arr[0] = 12;
    arr.length // 1

    arr.length = 0;
    arr[0]
}
{
    class VersionedArray extends Array {
        constructor() {
            super();
            this.history = [[]];
        }
        commit() {
            this.history.push(this.slice());
        }
        revert() {
            this.splice(0, this.length, ...this.history[this.history.length - 1]);
        }
    }

    var x = new VersionedArray();
    x.push(1);
    x.push(2);
    x // [1, 2]
    x.history // [[]]
    x.commit();
    x.history // [[], [1, 2]]
    x.push(3);
    x // [1, 2, 3]
    x.history // [[], [1, 2]]
    x.revert();
    x // [1, 2]
}