/*
Symbol原始数据类型
 */
{
    //格式
    let s = Symbol();
    console.log(typeof s);
}
{
    let s1 = Symbol('foo');
    let s2 = Symbol('bar');
    console.log(s1.toString(),s2.toString());
}
{
    //注意，Symbol函数的参数只是表示对当前 Symbol 值的描述，因此相同参数的Symbol函数的返回值是不相等的。
    let s1 = Symbol();
    let s2 = Symbol();
    console.log(Object.is(s1, s2));
    let s3 = Symbol('foo');
    let s4 = Symbol('foo');
    console.log(Object.is(s3, s4));
}
{
    let mySymbol = Symbol();
// 第一种写法
    let a1 = {};
    a1[mySymbol] = 'Hello!';
// 第二种写法
    let a2 = {
        [mySymbol]: 'Hello!'
    };
// 第三种写法
    let a3 = {};
    Object.defineProperty(a3, mySymbol, {value: 'Hello!'});

// 以上写法都得到同样结果
    console.log(a1[mySymbol], a2[mySymbol], a3[mySymbol]);
}
{
    const mySymbol = Symbol();
    const a = {};
    a.mySymbol = 'Hello!';
    a[mySymbol] // undefined
    a['mySymbol'] // "Hello!"
}
{
    const log = {};

    log.levels = {
        DEBUG: Symbol('debug'),
        INFO: Symbol('info'),
        WARN: Symbol('warn')
    };
    console.log(log.levels.DEBUG, 'debug message');
    console.log(log.levels.INFO, 'info message');
}
{
    const COLOR_RED    = Symbol("red");
    const COLOR_GREEN  = Symbol("green");

    function getComplement(color) {
        switch (color) {
            case COLOR_RED:
                return COLOR_GREEN;
            case COLOR_GREEN:
                return COLOR_RED;
            default:
                throw new Error('Undefined color');
        }
    }
}
{
    function getArea(shape, options) {
        let area = 0;
        switch (shape) {
            case 'Triangle': // 魔术字符串
                area = .5 * options.width * options.height;
                break;
            /* ... more code ... */
        }
        return area;
    }
    let area = getArea('Triangle', { width: 100, height: 100 });
    console.log("Triangle的面积："+area);

}
{
    const shaps ={
        'Triangle':Symbol()
    }
    function getArea(shape, options) {
        let area = 0;
        switch (shape) {
            case shaps.Triangle:
                area = .5 * options.width * options.height;
                break;
            /* ... more code ... */
        }
        return area;
    }
    let area = getArea(shaps.Triangle, { width: 100, height: 100 });
    console.log(area);
}
{
    const obj = {};
    let a = Symbol('a');
    let b = Symbol('b');
    obj[a] = 'Hello';
    obj[b] = 'World';
    const objectSymbols = Object.getOwnPropertySymbols(obj);
    console.log(objectSymbols);
}
{
    const obj = {bar:'bar'};
    let foo = Symbol("foo");
    Object.defineProperty(obj, foo, {
        value: "foobar",
    });
    for (let i in obj) {
        console.log(i);
    }
    const props = Object.getOwnPropertyNames(obj);
    console.log('props:'+props);
    const syms = Object.getOwnPropertySymbols(obj)
    console.log('syms:',syms);
    const allProps= Reflect.ownKeys(obj);
    console.log("all props:", allProps);
}
{
    /*let s1 = Symbol.for('foo');
    let s2 = Symbol.for('foo');

    console.log(s1===s2);*/

    let s1 = Symbol.for("foo");
    console.log(Symbol.keyFor(s1));

    let s2 = Symbol("foo");
    console.log(Symbol.keyFor(s2));
}
{
   /* class Even {
        static [Symbol.hasInstance](obj) {
            return Number(obj) % 2 === 0;
        }
    }*/
    const Even = {
        [Symbol.hasInstance](obj) {
            return Number(obj) % 2 === 0;
        }
    };
    console.log(1 instanceof Even);
    console.log(2 instanceof Even);
    console.log(12345 instanceof Even);
}
{
    let arr1 = ['c', 'd'];
    console.log(['a', 'b'].concat(arr1, 'e'));
    console.log(arr1[Symbol.isConcatSpreadable]);

    let arr2 = ['c', 'd'];
    console.log(arr2[Symbol.isConcatSpreadable] = false);
    console.log(['a', 'b'].concat(arr2, 'e'));
}
{
    let obj = {length: 2, 0: 'c', 1: 'd'};
    console.log(['a', 'b'].concat(obj, 'e'));

    obj[Symbol.isConcatSpreadable] = true;
    console.log(['a', 'b'].concat(obj, 'e'));
}