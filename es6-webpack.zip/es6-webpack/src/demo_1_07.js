/*
对象的扩展
 */
{
    //属性的简洁表示法
    const foo = 'bar';
    const baz = {foo};//等同于 baz = {foo:foo}
    console.log(baz);

    //方法的简写
    const obj = {
        fun() {
            return 'Hello!';
        }
    }
    console.log(obj.fun());

    let birth = '2000/01/01';
    const Person = {
        name: '张三',
        //等同于birth: birth
        birth,
        // 等同于hello: function ()...
        hello() { console.log('我的名字是', this.name); }
    };

    //作为函数的返回值
    function getPoint() {
        const x = 1;
        const y = 10;
        return {x, y};
    }
   console.log(getPoint());
}
{
    const cart = {
        _wheels: 4,

        get wheels () {
            return this._wheels;
        },

        set wheels (value) {
            if (value < this._wheels) {
                throw new Error('数值太小了！');
            }
            this._wheels = value;
        }
    }
    cart.wheels=20;
    console.log(cart.wheels);
}
{
    //使用字面量方式定义对象，ES6中允许使用表达式作为对象的属性名
    let propKey = 'foo';
    let obj = {
        [propKey]: true,
        ['a' + 'bc']: 123
    };
    console.log(obj.foo);
    console.log(obj[propKey]);
    console.log(obj['foo']);
   // console.log(obj[foo]);
}
{
    const person = {
        sayName() {
            console.log('hello!');
        }
    };

    console.log('方法名：',person.sayName.name);

    const obj = {
        get foo() {},
        set foo(x) {}
    };

    // obj.foo.name
    // TypeError: Cannot read property 'name' of undefined
    const descriptor = Object.getOwnPropertyDescriptor(obj, 'foo');
    console.log(descriptor.get.name);
    console.log(descriptor.set.name);
    //取值的方式
    console.log(obj.foo);
}
{
    let obj = { foo: 123 };
    let des = Object.getOwnPropertyDescriptor(obj, 'foo');
    console.log(des);
}
{
    let obj = Reflect.ownKeys({ [Symbol()]:0, b:0, 10:0, 2:0, a:0 });
    console.log(obj);
}
{
    const proto = {
        foo: 'hello'
    };
    const obj = {
        foo: 'world',
        find() {
            return super.foo;
        }
    };
    Object.setPrototypeOf(obj, proto);
    console.log(obj.find());
}
{
    let {x,y,a:z} = { x: 1, y: 2, a: 3, b: 4 };
    console.log(x,y,z);
}
{
    console.log(Object.is('foo', 'foo'));
    console.log(Object.is({}, {}));

    console.log( +0 === -0);
    console.log(NaN === NaN );

    console.log(Object.is(+0, -0));
    console.log(Object.is(NaN, NaN));

}
{
    const target = { a: 1 };
    const source1 = { b: 2 };
    const source2 = { c: 3 };
    Object.assign(target, source1, source2);
    console.log(target);
}
{
    const target = { a: 1, b: 1 };
    const source1 = { b: 2, c: 2 };
    const source2 = { c: 3 };
    Object.assign(target, source1, source2);
    console.log(target);
}
{
   /* Object.assign(undefined);
    Object.assign(null);*/
}
{
    Object.assign({b: 'c'},
        Object.defineProperty({}, 'invisible', {
            enumerable: false,
            value: 'hello'
        })
    )
}
{
    //object.assign方法的作用
    /*
    为对象添加属性
     */
    class Point {
        constructor(x, y) {
            Object.assign(this, {x, y})
        }
    }
    //克隆对象
  /*  function clone(origin) {
        return Object.assign({}, origin);
    }*/

    function clone(origin) {
        let originProto = Object.getPrototypeOf(origin);
        return Object.assign(Object.create(originProto), origin);
    }

}
{
    //合并对象
    //1、将多个对象合并到某个对象
    const merge = (target,...source)=>Object.assign(target,...source);
   console.log( merge({},{a:1},{b:4},{c:39}));
}
{
    //为属性指定默认值
    const DEFAULTS ={
        logLevel: 0,
        outputFormat: 'JSON'
    }
    function processContent(options) {
        options = Object.assign({}, DEFAULTS, options);
        console.log(options);
    }
    processContent();
    processContent({logLevel: 1})
}
{
    const obj = {
        foo: 123,
        get bar() { return 'abc' }
    };
   console.log( Object.getOwnPropertyDescriptors(obj));
}
{
    const source = {
        set foo(value) {
            console.log(value);
        }
    };
    const target1 = {};
    Object.assign(target1, source);
    console.log(Object.getOwnPropertyDescriptor(target1, 'foo'));
}
{
    const source = {
        set foo(value) {
            console.log(value);
        }
    };
    const target2 = {};
    Object.defineProperties(target2, Object.getOwnPropertyDescriptors(source));
    console.log( Object.getOwnPropertyDescriptor(target2, 'foo'));
}
{
    //实现对象的继承(ES5)
/*    let prop = {age: 18};
    let  obj ={
         __proto__:prop,
         foo:123
     }*/
    //ES6
    const prop = {age: 18};
    const obj = Object.create(prop);
    obj.foo = 123;
    console.log(Object.getPrototypeOf(obj).age);
    //或者
    const obj2 = Object.assign(
        Object.create(prop),
        {
            foo: 123,
        }
    );
    console.log("obj2.age:"+Object.getPrototypeOf(obj2).age)

    const obj3 = Object.create(
        prop,
        Object.getOwnPropertyDescriptors({
            foo: 123,
        })
    );
}
{
    // 对象的原型
    // 格式： Object.setPrototypeOf(object, prototype)
    const o = Object.setPrototypeOf({}, null);
    console.log("o对象的原型：" + Object.getPrototypeOf(o));
    let proto = {};
    let obj = {x: 10};
    Object.setPrototypeOf(obj, proto);
    proto.y = 20;
    proto.z = 40;
    console.log(obj.x, obj.y, obj.z);
}
{
    //获取对象的原型
    function Foo(){
        //TODO
    }
    const foo = new Foo();
    console.log(Object.getPrototypeOf(foo) === Foo.prototype);
    Object.setPrototypeOf(foo,Object.prototype);
    console.log(Object.getPrototypeOf(foo) === Foo.prototype);
    //如果参数不是对象，会被自动转为对象。
    console.log(Object.getPrototypeOf(1) === Number.prototype);
    console.log(Object.getPrototypeOf('foo') === String.prototype);
    console.log(Object.getPrototypeOf(true) === Boolean.prototype);
}