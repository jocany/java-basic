/*
*  数组的扩展
*/
{
  console.log(...[3,4,5]);
  console.log(1,...[2,3],4);

  function add(x,y){
      return x+y;
  }
  console.log(add(...[5,20]));
}
{
    //复制数组
    var arr1 = [3, 4];
    var arr2=arr1;
    arr2[0]=10;
    console.log(...arr1)
    //ES5中的做法
    var arr3=arr1.concat();
    arr3[0]=9;
    console.log(...arr1);//10,4
    //ES6中的做法
    var arr4=[...arr1];
    arr4[0]=20;
    console.log(...arr1);//10,4
}
{
    //数组合并
    const arr1 = ['a', 'b'];
    const arr2 = ['c'];
    const arr3 = ['d', 'e'];
    //ES5
    const narr1=arr1.concat(arr2,arr3);
    console.log(narr1)
    //ES6
    const narr2=[...arr1,...arr2,...arr3];
    console.log(narr2);
}
{
    //字符串
    const str="hello";
    const con=[...str];
    console.log(con);
}
{
    //实现了 Iterator 接口的对象
    let nodeList = document.querySelectorAll('div');
    let array = [...nodeList];
}
{
    let map = new Map([
        [1, 'one'],
        [2, 'two'],
        [3, 'three'],
    ]);

    let arr = [...map.keys()];
    console.log(...arr)
}
{
    let arrayLike = {
        '0': 'a',
        '1': 'b',
        '2': 'c',
        length: 3
    };
    // ES5的写法
    var arr1 = [].slice.call(arrayLike);
    console.log("ES5:",...arr1);
    // ES6的写法
    let arr2 = Array.from(arrayLike);
    console.log("ES6:",...arr2)

}
{
    const arr = Array.of(3, 11, 8);
    const arr2 = Array.of(3);
    const len = Array.of(3).length;
    console.log(arr,arr2,len);

    var a1 = new Array();
    var a2 = new Array(3);
    var a3 = new Array(1,2,3);
    console.log(a1,a2,a3);

}

{
    //copyWithin
   const arr1 = [1, 2, 3, 4, 5].copyWithin(0, 3);
   const arr2 = [1, 2, 3, 4, 5].copyWithin(0, 3, 4);
   const arr3 = [1, 2, 3, 4, 5].copyWithin(0, -2, -1);
    // 将3号位复制到0号位
   const arr4 = [].copyWithin.call({length: 5, 3: 1}, 0, 3);

   console.log(arr1, arr2, arr3, arr4);
}
{
    //find()方法：找到第一个满足条件的元素并返回，如果没有找到返回undefined
    let sear = [1, 4, -5, 10].find((n) => n < 0);
    console.log(sear);

    //findIndex()方法：找到第一个满足条件的元素并返回索引，如果没有找到返回-1
    let index = [1, 4, -5, 10].findIndex((n) => n < 0);
    console.log(index);

}
{
    //keys(),values(), entries()
    let arr = ["orange","peak","watermelon"];
    for(let key of arr.keys()){
        console.log(key)
    }
    for(let val of arr.values()){
        console.log(val)
    }
    for(let [key,val] of arr.entries()){
        console.log(key+"---"+val);
    }

    let entries = arr.entries();
    console.log(entries.next().value);
    console.log(entries.next().value);
    console.log(entries.next().value);
}
{
    //数组的includes()
    let arr = [1,5,9,NaN];
    console.log(arr.includes(5));
    console.log(arr.includes(10));
    console.log(arr.includes(NaN));


    console.log(arr.includes(5,2));
    console.log(arr.includes(9,-5));
}
{
    //flat 和flatMap 拉平数组
    console.log([1,2,4,[7,9]].flat());

    console.log([1,2,4,[[7,8],9]].flat());
    console.log([1,2,4,[[7,8],9]].flat(2));

    console.log([1,2,4,[[7,8],9]].flat(Infinity));

    console.log([1,2,,4,[[7,,8],9]].flat(Infinity));

    console.log([1,2,4].flatMap(item =>[item,item * 2]))

}
{
    //数组的空位
    let arr1 = new Array(3);

    let arr2 = [undefined,undefined,undefined];

    console.log(0 in arr1);
    console.log(0 in arr2);

    console.log(Array.from(['a',,'b']));
    console.log([...['a',,'b']]);
    console.log([,'a','b',,].copyWithin(2,0));
    console.log(new Array(3).fill('a'));
    let arr = [, ,];
    for (let i of arr) {
        console.log(1);
    }
    console.log([...[,'a'].entries()]);
}
{

}