

/*
let和const命令

*/

/*
let:用来声明变量。它的用法类似于var，但是所声明的变量，只在let命令所在的代码块内有效
说明：在ES6中通过{}来指定作用域
 */

{
	let name="zhangsan";
	var age=20;
}

console.log("name="+name);
console.log("age="+age);

/*
常见案例:循环计数器中使用
*/
/*var arr=[];
for (var i = 0; i < 5; i++) {
	arr[i] = function(){
		console.log(i);
	};
}

*/
//解决方案1：使用立即执行函数表达式
/*var arr=[];
for (var i = 0; i < 5; i++) {
	!function(i){
		arr[i] = function(){
			console.log(i);
		};
	}(i)
}*/

//解决方案2：使用let
var arr=[];
for (let i = 0; i < 5; i++) {
	arr[i] = function(){
		console.log(i);
	};
}
for(var j=0;j<arr.length;j++){
	arr[j]();
}


// var 的情况
{
	console.log(foo); // 输出undefined
	var foo = 2;

// let 的情况
	console.log(typeof bar);
	let bar = 2;
}
//暂时性死区
var tmp = 123;

if (true) {
	tmp = 'abc'; // ReferenceError
	let tmp;
}

//不允许重复声明
//let不允许在相同作用域内，重复声明同一个变量。
{
	let a = 19;
	//let a = "xiaoming";
}

//因此不能在函数内部重新声明参数
/*function func(arg) {
	let arg;
}
func() */// 报错

/*function func(arg) {
	{
		let arg;
	}
}
func()*/ // 不报错

//块作用域
var tmp = new Date();

function f() {
	console.log(tmp);
	if (false) {
		var tmp = 'hello world';
	}
}

f(); // undefined

//let实际上为 JavaScript 新增了块级作用域。
function f1() {
	let n = 5;
	if (true) {
		let n = 10;
	}
	console.log(n); // 5
}

f1();



/*
const 声明常量
ES5中创建常量的方式，ES3中没有常量的概念
*/
Object.defineProperty(window,'PI1',{
	value:3.1425,
	writable:false
});
console.log("PI1 = "+window.PI1);
/*ES6中常量的写法*/
const PI2 = 3.1415936
console.log("PI2 = "+PI2);
