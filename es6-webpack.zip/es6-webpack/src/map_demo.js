/*
map的遍历
 */
{
    const map = new Map([['F', 'no'], ['T', 'yes']]);
    for (let key of map.keys()) {
        console.log(key);
    }
    for (let value of map.values()) {
        console.log(value);
    }
    for (let item of map.entries()) {
        console.log(item[0], item[1]);
    }
    for (let [key, value] of map.entries()) {
        console.log(key, value);
    }
// 等同于使用map.entries()
    for (let [key, value] of map) {
        console.log(key, value);
    }
}
{
    const map = new Map([
        [1, 'one'],
        [2, 'two'],
        [3, 'three'],
    ]);

    console.log([...map.keys()]);

    console.log([...map.values()]);

    console.log([...map.entries()]);

    console.log([...map]);

}
{
    function strMapToObj(strMap) {
        let obj = Object.create(null);
        for (let [k,v] of strMap) {
            obj[k] = v;
        }
        return obj;
    }

    const myMap = new Map()
        .set('yes', true)
        .set('no', false);
    console.log(strMapToObj(myMap));
}
{
    function objToStrMap(obj) {
        let strMap = new Map();
        for (let k of Object.keys(obj)) {
            strMap.set(k, obj[k]);
        }
        return strMap;
    }

    objToStrMap({yes: true, no: false})
}
{
    function strMapToObj(strMap) {
        let obj = Object.create(null);
        for (let [k,v] of strMap) {
            obj[k] = v;
        }
        return obj;
    }
    function strMapToJson(strMap) {
        return JSON.stringify(strMapToObj(strMap));
    }

    let myMap = new Map().set('yes', true).set('no', false);
    console.log(strMapToJson(myMap));
}
{
    function objToStrMap(obj) {
        let strMap = new Map();
        for (let k of Object.keys(obj)) {
            strMap.set(k, obj[k]);
        }
        return strMap;
    }
    function jsonToStrMap(jsonStr) {
        return objToStrMap(JSON.parse(jsonStr));
    }

    console.log(jsonToStrMap('{"yes": true, "no": false}'));
}