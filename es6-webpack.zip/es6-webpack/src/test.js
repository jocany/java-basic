/**
 * [description]
 * @returns {[type]} [description]
 */
export default function() {
    window.console.log("b")
}
