/*
*  二进制和八进制新的表示方法
*/
{
    //ES6 提供了二进制和八进制数值的新的写法，分别用前缀0b（或0B）和0o（或0O）表示

    console.log(0b111110111 === 503);
    console.log(0o767 === 503 );
    //如果要将带有0b和0o前缀的字符串数值转为十进制，要使用Number方法。
    console.log(Number(0b1101));
    console.log(Number(0o75));

    console.log(Number.isFinite(15));
    console.log(Number.isFinite(NaN));
    console.log(Number.isFinite(true));
    Number.isFinite(0.8); // true
    Number.isFinite(Infinity); // false
    Number.isFinite(-Infinity); // false
    Number.isFinite('foo'); // false
    Number.isFinite('15'); // false



    //isNaN方法
    console.log(Number.isNaN(NaN));
    console.log(Number.isNaN(15));
    console.log( Number.isNaN('15'));
    Number.isNaN(true) // false
    Number.isNaN(9/NaN) // true
    Number.isNaN('true' / 0) // true
    Number.isNaN('true' / 'true') // true


}
{
    // ES5的写法
    console.log(parseInt('12.34'));
    console.log(parseFloat('123.45'));

    // ES6的写法
    console.log(Number.parseInt('12.34'));
    console.log(Number.parseFloat('123.45'));
}

{
    console.log(Number.isInteger(12));
    console.log(Number.isInteger(12.5));
    console.log(Number.isInteger(12.0));
    console.log(Number.isInteger());
    console.log(Number.isInteger(null));
    console.log(Number.isInteger("12"));
    console.log(Number.isInteger(true));
    console.log(Number.isInteger(3.0000000000000002));

}
{
    //函数的length属性
    function foo(x,y,z=9) {
        return Math.max(x, y, z)
    }

     console.log(foo.length);

    function foo2(...values) {
        return values.toString();
    }
    console.log(foo2.length);
}

{
    function throwIfMissing() {
        throw new Error('Missing parameter');
    }

    function foo(mustBeProvided = throwIfMissing()) {
        return mustBeProvided;
    }
    foo();

}
