//import test from "./src/test"
//import demo08 from  "./src/symbol_demo"
//import setdemo from  "./src/set_demo"
/*import moduledemo from  "./src/module_demo"*/

/*import {firstName as fn,lastName as ln,year,obj} from "./src/module_demo.js"
console.log(`${fn},${ln}`);

obj.name = '张三丰';
obj.age = 58;
console.log(obj.name);*/


import * as module from "./src/module_demo"

console.log("圆的面积："+module.area(4))
console.log("圆的周长："+module.circumference(4))